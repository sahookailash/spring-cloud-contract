package contractproducer.springcloudcontractproducer.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class EvenOddController {

    @GetMapping("/validate/prime-number")
    public String isNumberPrime(@RequestParam("number") Integer number) {
        return number % 2 == 0 ? "Even" : "Odd";
    }

    @PostMapping(value = "/save/{number}",produces = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<String> savePrimeNumber(@PathVariable("number")Integer number,@RequestBody Object request){

        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_TYPE, MediaType.TEXT_PLAIN_VALUE);

        return ResponseEntity.ok()
                .headers(headers)
                .body("saved");
    }



}
